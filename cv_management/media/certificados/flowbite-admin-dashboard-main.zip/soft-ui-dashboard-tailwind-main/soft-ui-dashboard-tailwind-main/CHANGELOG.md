# Change Log

## [1.0.5] 2022-08-05
### Bug Fixing
- fix sidenav color plugin
- fix chips' padding

## [1.0.4] 2022-08-04
### Bug Fixing
- refactor custom classes
- add pro button
- rename styles file
- update documentation

## [1.0.3] 2022-06-24
### Bug Fixing
- update script imports

## [1.0.2] 2022-06-14
### Bug Fixing
- fix documentation link

## [1.0.1] 2022-06-10
### Bug Fixing
- update github buttons link

## [1.0.0] 2022-06-07
### Original Release